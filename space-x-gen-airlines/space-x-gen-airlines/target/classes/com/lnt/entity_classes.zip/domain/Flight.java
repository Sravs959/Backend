package com.lnt.domain;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
@Table(name="FLIGHT_DETAILS")
public class Flight {
	@Id
	@Column(name = "flight_Id") private Integer flightId;
	
	@OneToMany(mappedBy = "flight")
	private List<FlightSchedule> scheduleList;
	
	private String flightModel;
	private String carrierName;
	private Integer seatCap;
	private String sourceCity;
	private String destinationCity;

	
	public List<FlightSchedule> getScheduleList() {
		return scheduleList;
	}

	public void setScheduleList(List<FlightSchedule> scheduleList) {
		this.scheduleList = scheduleList;
	}

	// Default Constructor
	public Flight() {
		super();
	}

	public Flight(Integer flightId, String flightModel, String carrierName, Integer seatCap, String sourceCity,
			String destinationCity) {
		super();
		this.flightId = flightId;
		this.flightModel = flightModel;
		this.carrierName = carrierName;
		this.seatCap = seatCap;
		this.sourceCity = sourceCity;
		this.destinationCity = destinationCity;
	}

	public Integer getFlightId() {
		return flightId;
	}

	public void setFlightId(Integer flightId) {
		this.flightId = flightId;
	}

	public String getFlightModel() {
		return flightModel;
	}

	public void setFlightModel(String flightModel) {
		this.flightModel = flightModel;
	}

	public String getCarrierName() {
		return carrierName;
	}

	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

	public Integer getSeatCap() {
		return seatCap;
	}

	public void setSeatCap(Integer seatCap) {
		this.seatCap = seatCap;
	}

	public String getSourceCity() {
		return sourceCity;
	}

	public void setSourceCity(String sourceCity) {
		this.sourceCity = sourceCity;
	}

	public String getDestinationCity() {
		return destinationCity;
	}

	public void setDestinationCity(String destinationCity) {
		this.destinationCity = destinationCity;
	}

}
