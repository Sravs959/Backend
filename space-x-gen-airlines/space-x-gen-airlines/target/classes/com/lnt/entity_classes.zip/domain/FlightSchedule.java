package com.lnt.domain;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "FLIGHT_SCHEDULE")
public class FlightSchedule {

	@Id
	private int tripCode;
	
	@ManyToOne
	@JoinColumn(name = "flight_Id")
	private Flight flight;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate date;
	
	@JsonFormat(pattern="hh-mm-ss")
	private LocalTime time;
	
	private Float journeyTime;
	private Integer noOfTickets;
	private String source;
	private String destination;
	private Float offers;
	@OneToMany(mappedBy="schedule")
	private List<UserDetails> user;
	
	public void setUser(List<UserDetails> user) {
		this.user = user;
	}

	

	
	public List<UserDetails> getUser() {
		return user;
	}

	public Float getOffers() {
		return offers;
	}

	public void setOffers(Float offers) {
		this.offers = offers;
	}

	public int getTripCode() {
		return tripCode;
	}

	public void setTripCode(int tripCode) {
		this.tripCode = tripCode;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public LocalTime getTime() {
		return time;
	}

	public void setTime(LocalTime time) {
		this.time = time;
	}

	public Float getJourneyTime() {
		return journeyTime;
	}

	public void setJourneyTime(Float journeyTime) {
		this.journeyTime = journeyTime;
	}

	public Integer getNoOfTickets() {
		return noOfTickets;
	}

	public void setNoOfTickets(Integer noOfTickets) {
		this.noOfTickets = noOfTickets;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

}
