package com.lnt.domain;


import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonFormat;

@XmlRootElement
@Entity
@Table(name = "BOOKING_DETAILS")
public class BookingDetails {
	@Id
	@Column(name="Booking_Id") private Integer bookingId;
	
	@OneToMany
	@JoinColumn(name="User_Id")
	private UserDetails UserId;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate bookingDate;
	
	@OneToMany(mappedBy="booking")
	private List<PassengerDetails> listOfPassengers;
	
	private Float ticketCost;
	private Flight flight;
	private String ticketType;
	
	public BookingDetails() {
		super();
	}

	public Integer getBookingId() {
		return bookingId;
	}

	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}

	public UserDetails getUserId() {
		return UserId;
	}

	public void setUserId(UserDetails userId) {
		UserId = userId;
	}

	public LocalDate getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}

	public List<PassengerDetails> getListOfPassengers() {
		return listOfPassengers;
	}

	public void setListOfPassengers(List<PassengerDetails> listOfPassengers) {
		this.listOfPassengers = listOfPassengers;
	}

	public Float getTicketCost() {
		return ticketCost;
	}

	public void setTicketCost(Float ticketCost) {
		this.ticketCost = ticketCost;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	public String getTicketType() {
		return ticketType;
	}

	public void setTicketType(String ticketType) {
		this.ticketType = ticketType;
	}
	
	

	
}
