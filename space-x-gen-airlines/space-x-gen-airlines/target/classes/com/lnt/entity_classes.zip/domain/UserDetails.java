package com.lnt.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
@Table(name="USER_DETAILS")
public class UserDetails {

	@Id
//	@GeneratedValue
	
	@Column(name="user_Id") private Integer userId;

	private String userName;
	private String password;
	private Double phoneNo;
	private String email;
	
	@ManyToOne
	@JoinColumn(name="tripCode")
	private FlightSchedule schedule;

	// Default Constructor
	public UserDetails() {
		super();
	}

	public UserDetails(Integer userId, String userName, String password, Double phoneNo, String email) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.phoneNo = phoneNo;
		this.email = email;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Double getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Double phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
